package com.cts.microservice.adminreport.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class AdminServiceImplTest {

	@Test
	void testDeleteThePost() {
	}

}
