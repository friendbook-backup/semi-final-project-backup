package com.cts.microservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdminReportApplicationTests {

	@Test
	void contextLoads() {
	}

}
